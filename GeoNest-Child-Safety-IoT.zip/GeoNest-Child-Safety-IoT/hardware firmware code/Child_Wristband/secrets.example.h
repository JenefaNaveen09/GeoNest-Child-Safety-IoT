#pragma once

#define WIFI_SSID "YOUR_WIFI_SSID"
#define WIFI_PASSWORD "YOUR_WIFI_PASSWORD"
// Replace with the station MAC printed by your central hub.
#define HUB_MAC {0, 0, 0, 0, 0, 0}
// Leave empty to disable SMS.
#define PARENT_PHONE_NUMBER ""
// Fill all three fields locally to enable Firebase writes.
#define FIREBASE_HOST ""
#define FIREBASE_AUTH ""
#define FIREBASE_ROOT_CA ""
