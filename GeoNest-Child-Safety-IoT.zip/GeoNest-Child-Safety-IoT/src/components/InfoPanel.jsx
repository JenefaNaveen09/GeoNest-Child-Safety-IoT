
export default function InfoPanel({ data, status, activeAlerts = [] }) {
  const { childName, childAge, deviceId, parentContact, latitude, longitude, lastUpdated, zones = [], currentRoom, heartRate, spo2, temperature, humidity, posture, activity } = data;

  // Check for high temperature alert (>37.5°C)
  const isHighTemp = temperature && temperature > 37.5;

  // Activity indicator styling
  const getActivityStyle = (act) => {
    switch (act) {
      case "Running": return "bg-red-100 text-red-700";
      case "Walking": return "bg-amber-100 text-amber-700";
      case "Standing": return "bg-emerald-100 text-emerald-700";
      default: return "bg-slate-100 text-slate-700";
    }
  };

  const getStatusConfig = () => {
    // Check for HEALTH_EMERGENCY (highest priority - SpO2 < 90 + Fallen)
    const isHealthEmergency = activeAlerts.includes("HEALTH_EMERGENCY");

    if (isHealthEmergency) {
      return { color: "bg-purple-600", text: "text-purple-700", bg: "bg-purple-50", label: "Health Emergency", icon: "🏥" };
    }

    switch (status) {
      case "OFFLINE":
        return { color: "bg-slate-500", text: "text-slate-700", bg: "bg-slate-100", label: "Device Disconnected", icon: "🔌" };
      case "FALLEN":
        return { color: "bg-rose-500", text: "text-rose-700", bg: "bg-rose-50", label: "Medical Emergency", icon: "🚑" };
      case "INSIDE":
        return { color: "bg-emerald-500", text: "text-emerald-700", bg: "bg-emerald-50", label: "Inside Safe Zone", icon: "✓" };
      case "OUTSIDE":
        return { color: "bg-red-500", text: "text-red-700", bg: "bg-red-50", label: "Outside Zone", icon: "!" };
      default:
        return { color: "bg-slate-400", text: "text-slate-700", bg: "bg-slate-100", label: "No Zone Defined", icon: "-" };
    }
  };

  const statusConfig = getStatusConfig();
  const formatTime = (isoString) => {
    if (!isoString) return "Unknown";
    return new Date(isoString).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  };

  return (
    <div className="h-full flex flex-col p-6 overflow-y-auto bg-white border-r border-slate-200 shadow-[4px_0_24px_-12px_rgba(0,0,0,0.1)] z-10 relative custom-scrollbar">

      {/* Header Profile Section */}
      <div className="flex items-center space-x-4 mb-6">
        <div className="h-16 w-16 rounded-full bg-gradient-to-tr from-blue-500 to-indigo-500 flex items-center justify-center text-white text-2xl font-bold shadow-md ring-4 ring-blue-50 overflow-hidden">
          <span aria-hidden="true">GN</span>
        </div>
        <div>
          <h2 className="text-2xl font-bold text-slate-800 tracking-tight">{childName}</h2>
          <p className="text-sm font-medium text-slate-500">Age: {childAge || "-"}</p>
        </div>
      </div>

      {/* Status Card */}
      <div className={`rounded-xl p-4 mb-5 border ${statusConfig.bg === 'bg-red-50' || statusConfig.bg === 'bg-rose-50' ? 'border-red-200' : 'border-slate-100'} ${statusConfig.bg} shadow-sm transition-all duration-300`}>
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">Live Status</h3>
        <div className="flex items-center space-x-3">
          <div className={`relative flex h-4 w-4`}>
            {(status === "OUTSIDE" || status === "FALLEN" || activeAlerts.includes("HEALTH_EMERGENCY")) && <span className={`animate-ping absolute inline-flex h-full w-full rounded-full ${statusConfig.color} opacity-75`}></span>}
            <span className={`relative inline-flex rounded-full h-4 w-4 ${statusConfig.color}`}></span>
          </div>
          <span className={`text-lg font-bold ${statusConfig.text}`}>{statusConfig.label}</span>
        </div>
        <div className="mt-2 text-xs text-slate-500 flex items-center space-x-1">
          <span>⏱</span>
          <span>Last ping: {formatTime(lastUpdated)}</span>
        </div>
      </div>

      {/* Vitals Grid */}
      <div className="bg-slate-50 rounded-xl p-4 border border-slate-100 mb-5">
        <div className="flex items-center justify-between mb-3 border-b border-slate-200 pb-2">
          <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1">
            <span className="text-rose-500">❤️</span> Health Vitals
          </h3>
          <div className="flex gap-2">
            {activity && (
              <span className={`px-2 py-0.5 rounded text-xs font-bold ${getActivityStyle(activity)}`}>
                {activity}
              </span>
            )}
            <span className={`px-2 py-0.5 rounded text-xs font-bold ${posture === 'Fallen!' ? 'bg-rose-100 text-rose-700 animate-pulse' : 'bg-blue-100 text-blue-700'}`}>
              {posture || "-"}
            </span>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3 text-sm">
          <div className="flex flex-col">
            <span className="text-slate-400 text-xs">Heart Rate (<span className="text-rose-500 font-bold">♥</span>)</span>
            <span className={`font-bold text-lg ${heartRate > 120 ? 'text-amber-600' : 'text-slate-700'}`}>
              {heartRate ?? "-"}<span className="text-xs text-slate-400 font-normal ml-1">bpm</span>
            </span>
          </div>
          <div className="flex flex-col">
            <span className="text-slate-400 text-xs">O2 Saturation (💧)</span>
            <span className={`font-bold text-lg ${spo2 < 90 ? 'text-red-600' : 'text-slate-700'}`}>
              {spo2 ?? "-"}<span className="text-xs text-slate-400 font-normal ml-1">%</span>
            </span>
          </div>
          <div className="flex flex-col">
            <span className="text-slate-400 text-xs">Body Temperature (🌡️)</span>
            <span className={`font-bold text-lg ${isHighTemp ? 'text-red-600' : 'text-slate-700'}`}>
              {temperature ?? "-"}<span className="text-xs text-slate-400 font-normal ml-1">°C</span>
              {isHighTemp && <span className="ml-1 text-xs">🔥</span>}
            </span>
          </div>
          <div className="flex flex-col">
            <span className="text-slate-400 text-xs">Humidity (☁️)</span>
            <span className="font-bold text-slate-700 text-lg">{humidity ?? "-"}<span className="text-xs text-slate-400 font-normal ml-1">%</span></span>
          </div>
        </div>
      </div>

      {/* Details Grid */}
      <div className="grid grid-cols-1 gap-3 mb-5">
        <div className="bg-slate-50 rounded-lg p-3 border border-slate-100 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="text-slate-400">📱</span>
            <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider">ID</h3>
          </div>
          <p className="text-slate-800 font-medium font-mono text-sm">{deviceId}</p>
        </div>

        <div className="bg-slate-50 rounded-lg p-3 border border-slate-100 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="text-slate-400">📞</span>
            <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Contact</h3>
          </div>
          <p className="text-slate-800 font-medium text-sm">{parentContact}</p>
        </div>

        {!currentRoom || currentRoom === "Outdoors" ? (
          <div className="bg-slate-50 rounded-lg p-3 border border-slate-100">
            <div className="flex items-center space-x-2 mb-2">
              <span className="text-slate-400">📍</span>
              <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Outdoor GPS Location</h3>
            </div>
            <div className="flex justify-between ml-6 text-sm">
              <div><span className="text-slate-400 text-xs">Lat:</span> <span className="font-mono text-slate-700 text-xs">{latitude?.toFixed(5) || "-"}</span></div>
              <div><span className="text-slate-400 text-xs">Lng:</span> <span className="font-mono text-slate-700 text-xs">{longitude?.toFixed(5) || "-"}</span></div>
            </div>
          </div>
        ) : (
          <div className="bg-blue-50/50 rounded-lg p-3 border border-blue-100 shadow-inner">
            <div className="flex items-center space-x-2 mb-1">
              <span className="text-blue-500">🏠</span>
              <h3 className="text-xs font-bold text-blue-800 uppercase tracking-wider">Indoor Detection</h3>
            </div>
            <div className="ml-6 flex items-center space-x-2">
              <span className="relative flex h-2.5 w-2.5"><span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span><span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-blue-500"></span></span>
              <span className="text-slate-800 font-bold">{currentRoom}</span>
            </div>
          </div>
        )}
      </div>

      {/* Allowed Zones List */}
      <div className="mb-4">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2 ml-1">Safe Zones ({zones.length}/3)</h3>
        {zones.length > 0 ? (
          <div className="space-y-2">
            {zones.map((zone, idx) => (
              <div key={idx} className="bg-white border text-xs border-slate-200 rounded-lg p-2.5 flex items-center space-x-3 shadow-sm">
                <div className="h-6 w-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center font-bold">{idx + 1}</div>
                <div>
                  <h4 className="font-semibold text-slate-700">Area {idx + 1}</h4>
                  <p className="text-[10px] text-slate-500">{Math.round(zone.radius)}m radius</p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-blue-50 border border-blue-100 rounded-lg p-3 text-center">
            <h4 className="font-semibold text-blue-900 text-xs mb-1">No Safe Zone Set</h4>
          </div>
        )}
      </div>

      <div className="flex-grow"></div>

      {/* Logo/Footer */}
      <div className="mt-4 text-center opacity-50 pb-2">
        <p className="text-[10px] font-bold tracking-widest text-slate-400 uppercase">GeoNest Band</p>
      </div>
    </div>
  );
}
