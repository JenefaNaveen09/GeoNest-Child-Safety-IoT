export default function ZoneControls({
  tempCenter,
  tempRadius,
  setTempRadius,
  zones,
  editingZoneIndex,
  setEditingZoneIndex,
  saving,
  onSaveNewZone,
  onSaveEdits,
  onDeleteZone,
  onCancelTemp,
}) {
  if (!tempCenter && zones.length === 0) return null;

  return (
    <div className="absolute bottom-4 left-4 bg-white rounded-xl shadow-lg p-4 min-w-[240px] space-y-3 max-h-[60vh] overflow-y-auto">
      {/* --- NEW ZONE CREATION --- */}
      {tempCenter && (
        <div className="space-y-3 bg-blue-50 p-3 rounded-lg border border-blue-100">
          <h3 className="font-semibold text-gray-800 text-sm">📍 New Safe Zone</h3>
          <div>
            <label className="block text-xs text-gray-500 mb-1">Radius (metres)</label>
            <input
              type="number"
              className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400"
              value={tempRadius}
              onChange={(e) => setTempRadius(e.target.value)}
              min={10}
              max={10000}
            />
          </div>
          <button
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg transition-colors disabled:opacity-50 text-sm"
            onClick={onSaveNewZone}
            disabled={saving}
          >
            {saving ? "Saving..." : "💾 Save New Zone"}
          </button>
          <button
            className="w-full bg-white hover:bg-gray-100 text-gray-600 border border-gray-200 font-medium py-2 px-4 rounded-lg transition-colors text-sm"
            onClick={onCancelTemp}
          >
            Cancel
          </button>
        </div>
      )}

      {/* --- EXISTING ZONES LIST --- */}
      {zones.length > 0 && !tempCenter && (
        <div className="space-y-3">
          <h3 className="font-semibold text-gray-800 text-sm flex justify-between items-center">
            <span>🛡️ Allowed Routes</span>
            <span className="text-xs font-normal text-gray-500 bg-gray-100 px-2 py-1 rounded-full">{zones.length}/3 Zones</span>
          </h3>

          <div className="space-y-2">
            {zones.map((zone, index) => {
              const isEditing = editingZoneIndex === index;

              return (
                <div key={index} className={`p-3 border rounded-lg ${isEditing ? 'border-amber-400 bg-amber-50' : 'border-gray-200 bg-white'}`}>
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-medium text-sm text-gray-700">Zone {index + 1}</span>
                    <span className="text-xs text-gray-500">{Math.round(zone.radius)}m</span>
                  </div>

                  {!isEditing ? (
                    <div className="flex space-x-2 mt-2">
                      <button
                        className="flex-1 bg-gray-100 hover:bg-amber-100 hover:text-amber-700 text-gray-700 font-medium py-1.5 px-2 rounded transition-colors text-xs"
                        onClick={() => setEditingZoneIndex(index)}
                        disabled={saving || editingZoneIndex !== null}
                      >
                        ✏️ Edit
                      </button>
                      <button
                        className="flex-1 bg-gray-100 hover:bg-red-100 hover:text-red-700 text-gray-700 font-medium py-1.5 px-2 rounded transition-colors disabled:opacity-50 text-xs"
                        onClick={() => onDeleteZone(index)}
                        disabled={saving || editingZoneIndex !== null}
                      >
                        🗑️ Del
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-2 mt-2">
                      <p className="text-xs text-amber-600 leading-tight">
                        Drag the yellow circle to move it, or drag its edges to resize.
                      </p>
                      <button
                        className="w-full bg-green-600 hover:bg-green-700 text-white font-medium py-1.5 px-2 rounded transition-colors disabled:opacity-50 text-xs"
                        onClick={onSaveEdits}
                        disabled={saving}
                      >
                        {saving ? "Saving..." : "✅ Ensure Changes"}
                      </button>
                      <button
                        className="w-full bg-white border border-amber-200 text-amber-700 hover:bg-amber-100 font-medium py-1.5 px-2 rounded transition-colors text-xs"
                        onClick={() => setEditingZoneIndex(null)}
                      >
                        Cancel
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
