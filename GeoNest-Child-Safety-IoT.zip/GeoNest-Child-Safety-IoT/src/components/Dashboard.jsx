import { useState, useEffect, useRef } from "react";
import useDeviceData from "../hooks/useDeviceData";
import MapView from "./MapView";
import InfoPanel from "./InfoPanel";
import AlertBanner from "./AlertBanner";
import { calculateDistance } from "../utils/distance";

export default function Dashboard() {
  const [deviceId] = useState("demo-wristband");
  const [smsTriggered, setSmsTriggered] = useState(false);
  const [activeAlerts, setActiveAlerts] = useState([]);
  const { data: firebaseData, error, loading } = useDeviceData(deviceId);
  const prevZoneStatus = useRef(null);
  const isFirstZoneCheck = useRef(true);
  const isSpo2Emergency = useRef(false);

  // ----- 15-MINUTE DATA RETENTION LOGIC -----
  // If lastUpdated is missing, we assume new data and don't expire it yet
  const timeSinceUpdate = firebaseData?.lastUpdated ? (new Date() - new Date(firebaseData.lastUpdated)) : 0;
  const isDataExpired = timeSinceUpdate > 900000; // 15 minutes (900,000ms)
  const isOffline = timeSinceUpdate > 120000;     // 2 minutes (120,000ms)

  // Combined profile details + hardware data with 15-min expiry guard
  // We use explicit undefined checks so that 0 values (like HR=0 or Lat=0) aren't cleared
  const data = {
    childName: "Demo Wristband",
    childAge: null,
    parentContact: "Demo profile",
    deviceId: deviceId,
    heartRate: (!isDataExpired && firebaseData?.heartRate !== undefined) ? firebaseData.heartRate : null,
    spo2: (!isDataExpired && firebaseData?.spo2 !== undefined) ? firebaseData.spo2 : null,
    temperature: (!isDataExpired && firebaseData?.temperature !== undefined) ? firebaseData.temperature : null,
    humidity: (!isDataExpired && firebaseData?.humidity !== undefined) ? firebaseData.humidity : null,
    posture: (!isDataExpired && firebaseData?.posture) ? firebaseData?.posture : "Waiting...",
    activity: (!isDataExpired && firebaseData?.activity) ? firebaseData?.activity : "Waiting...",
    currentRoom: (!isDataExpired && firebaseData?.currentRoom) ? firebaseData?.currentRoom : (isOffline ? "Device Offline" : "Waiting for Hub..."),
    latitude: (!isDataExpired && firebaseData?.latitude !== undefined) ? firebaseData.latitude : null,
    longitude: (!isDataExpired && firebaseData?.longitude !== undefined) ? firebaseData.longitude : null,
    lastUpdated: firebaseData?.lastUpdated || null,
    zones: firebaseData?.zones || [],
  };

  // Safely calculate status before any early returns to obey React Hook Rules
  let status = "NO_ZONE";
  let alertTypes = [];

  if (data) {
    const { latitude, longitude, zones = [], currentRoom, posture, heartRate, spo2, temperature } = data;

    if (isOffline) {
      status = "OFFLINE";
    } else {
      // --- FIX #4: SpO2 hysteresis (trigger <90%, clear >92%) ---
      if (spo2 && spo2 < 90) {
        isSpo2Emergency.current = true;
      } else if (spo2 && spo2 > 92) {
        isSpo2Emergency.current = false;
      }
      // isSpo2Emergency stays true between 90-92 (hysteresis buffer)

      // --- FIX #5: Mutually exclusive FALL vs HEALTH_EMERGENCY ---
      if (posture === "Fallen!") {
        status = "FALLEN";
        if (isSpo2Emergency.current) {
          // Combined fall + critically low SpO2 → HEALTH_EMERGENCY only
          alertTypes.push("HEALTH_EMERGENCY");
        } else {
          // Fall without SpO2 concern → standard FALL alert
          alertTypes.push("FALL");
        }
      }

      // --- FIX #2 & #12: Decouple indoor tracking from GPS zone checking ---
      // Set display status for indoor detection (only if not already fallen)
      if (status !== "FALLEN" && currentRoom && currentRoom !== "Outdoors") {
        status = "INSIDE";
      }

      // Always check GPS zone status regardless of indoor/outdoor display status
      if (zones.length > 0 && latitude != null && longitude != null) {
        let insideZone = false;
        let gpsZoneStatus = "OUTSIDE";
        for (const zone of zones) {
          const dist = calculateDistance(latitude, longitude, zone.center.lat, zone.center.lng);
          if (dist <= zone.radius) {
            gpsZoneStatus = "INSIDE";
            insideZone = true;
            break;
          }
        }

        // If not fallen and not detected indoors, use GPS zone status for display
        if (status !== "FALLEN" && (!currentRoom || currentRoom === "Outdoors")) {
          status = gpsZoneStatus;
        }

        // --- FIX #3: Suppress zone alerts on first data sync ---
        if (isFirstZoneCheck.current) {
          // Initialize prevZoneStatus without firing alerts on first load
          prevZoneStatus.current = gpsZoneStatus;
          isFirstZoneCheck.current = false;
        } else {
          // ZONE_BREACH: transition from inside → outside all zones
          if (!insideZone && prevZoneStatus.current === "INSIDE") {
            alertTypes.push("ZONE_BREACH");
          }
          // ZONE_RETURN: transition from outside → inside a zone
          if (insideZone && prevZoneStatus.current === "OUTSIDE") {
            alertTypes.push("ZONE_RETURN");
          }
          // Update previous zone status
          prevZoneStatus.current = gpsZoneStatus;
        }
      }

      // SMART ALERT CONDITIONS (Phase 4)

      // HEALTH_EMERGENCY from SpO2 alone (non-fall scenario)
      if (isSpo2Emergency.current && posture !== "Fallen!") {
        alertTypes.push("HEALTH_EMERGENCY");
      }

      // HEALTH_DANGER: Standing + HR >120
      if (posture === "Standing" && heartRate && heartRate > 120) {
        alertTypes.push("HEALTH_DANGER");
      }

      // HEAT_ALERT: Temperature >38°C
      if (temperature && temperature > 38) {
        alertTypes.push("HEAT_ALERT");
      }
    }
  }

  // Store active alerts for the AlertBanner to use
  const alertKey = JSON.stringify(alertTypes);
  useEffect(() => {
    setActiveAlerts(alertTypes);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [alertKey]);

  // Trigger Two-Way Communication "Push to Hardware" logic for emergencies
  useEffect(() => {
    if (status === "FALLEN" || activeAlerts.includes("ZONE_BREACH")) {
      const timer = setTimeout(() => setSmsTriggered(true), 2000);
      return () => clearTimeout(timer);
    } else {
      setSmsTriggered(false);
    }
  }, [status, activeAlerts]);

  // Premium Loading state
  if (loading) {
    return (
      <div className="h-screen flex items-center justify-center bg-slate-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-200 border-t-blue-600 mx-auto mb-4"></div>
          <p className="text-slate-500 font-medium text-lg">Connecting to wristband...</p>
        </div>
      </div>
    );
  }

  // Premium Error state - Only show if there's a critical configuration error
  if (error && !error.includes("not found")) {
    return (
      <div className="h-screen flex items-center justify-center bg-slate-50 p-4">
        <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md text-center border border-slate-100">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-red-100 mx-auto mb-6">
            <span className="text-red-600 text-3xl">⚠️</span>
          </div>
          <h2 className="text-2xl font-bold text-slate-800 mb-3">System Error</h2>
          <p className="text-slate-600 mb-6 bg-slate-50 p-3 rounded-lg text-sm border border-slate-100 font-mono">
            {error}
          </p>
        </div>
      </div>
    );
  }  // Render Component UI

  // Determine highest priority alert to display
  const getPriorityAlert = () => {
    const priorityOrder = ["HEALTH_EMERGENCY", "FALL", "HEAT_ALERT", "HEALTH_DANGER", "ZONE_BREACH", "ZONE_RETURN"];
    for (const alertType of priorityOrder) {
      if (activeAlerts.includes(alertType)) {
        return alertType;
      }
    }
    // Default to GEO alert if outside and no higher priority alerts
    if (status === "OUTSIDE" && !activeAlerts.includes("ZONE_BREACH")) {
      return "GEO";
    }
    return null;
  };

  const priorityAlert = getPriorityAlert();

  return (
    <div className="h-screen w-screen flex flex-col font-sans bg-slate-50 overflow-hidden relative">
      {/* Alert Banner with Priority System */}
      {priorityAlert && <AlertBanner alertType={priorityAlert} allAlerts={activeAlerts} />}

      {/* Simulation of SMS Polling Hook */}
      {smsTriggered && (
        <div className="absolute top-16 right-4 z-50 bg-slate-800 text-white px-4 py-2 rounded-full shadow-lg flex items-center space-x-2 animate-in slide-in-from-right-4">
          <span className="relative flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
          </span>
          <span className="text-xs font-bold tracking-wide">📡 COMMAND SENT TO HARDWARE: TRIGGER SMS</span>
        </div>
      )}

      {/* Main Layout Grid */}
      <div className="flex flex-grow overflow-hidden">
        {/* Left Side: Info Panel (350px fixed width for perfect presentation) */}
        <div className="w-[380px] flex-shrink-0 relative z-20">
          <InfoPanel data={data} status={status} activeAlerts={activeAlerts} />
        </div>

        {/* Right Side: Map View */}
        <div className="flex-grow relative z-10 bg-slate-200">
          <MapView data={data} status={status} />
        </div>
      </div>
    </div>
  );
}
