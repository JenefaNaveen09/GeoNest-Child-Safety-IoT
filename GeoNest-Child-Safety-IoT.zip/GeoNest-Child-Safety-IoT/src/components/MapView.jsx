import { GoogleMap, MarkerF, CircleF } from "@react-google-maps/api";
import { useState, useRef, useCallback } from "react";
import { ref, update } from "firebase/database";
import { rtdb } from "../firebase/config";
import ZoneControls from "./ZoneControls";

const mapContainerStyle = { height: "100%", width: "100%" };

const mapOptions = {
  disableDefaultUI: false,
  zoomControl: true,
  mapTypeControl: true,
  streetViewControl: false,
  fullscreenControl: true,
};

export default function MapView({ data, status }) {
  const { latitude, longitude, zones = [], deviceId } = data;

  const [tempCenter, setTempCenter] = useState(null);
  const [tempRadius, setTempRadius] = useState(200);
  const [editingZoneIndex, setEditingZoneIndex] = useState(null);
  const [saving, setSaving] = useState(false);
  const circleRefs = useRef({});
  const mapRef = useRef(null);

  const onMapLoad = useCallback((map) => {
    mapRef.current = map;
  }, []);

  const handleMapClick = (e) => {
    if (editingZoneIndex !== null || zones.length >= 3) return; // limit to 3 zones
    setTempCenter({
      lat: e.latLng.lat(),
      lng: e.latLng.lng(),
    });
  };

  const handleSaveNewZone = async () => {
    if (!tempCenter || !tempRadius) return;
    setSaving(true);
    try {
      const newZone = { center: tempCenter, radius: Number(tempRadius) };
      const updatedZones = [...zones, newZone];
      const deviceRef = ref(rtdb, `${deviceId}`);
      await update(deviceRef, { zones: updatedZones });
      setTempCenter(null);
    } catch (err) {
      alert("Failed to save zone: " + err.message);
    }
    setSaving(false);
  };

  const handleSaveEdits = async () => {
    if (editingZoneIndex === null || !circleRefs.current[editingZoneIndex]) return;
    setSaving(true);
    try {
      const circle = circleRefs.current[editingZoneIndex];
      const center = circle.getCenter();
      const radius = circle.getRadius();

      const updatedZones = [...zones];
      updatedZones[editingZoneIndex] = {
        center: { lat: center.lat(), lng: center.lng() },
        radius: radius,
      };

      const deviceRef = ref(rtdb, `${deviceId}`);
      await update(deviceRef, { zones: updatedZones });
      setEditingZoneIndex(null);
    } catch (err) {
      alert("Failed to save edits: " + err.message);
    }
    setSaving(false);
  };

  const handleDeleteZone = async (index) => {
    const confirmed = window.confirm(`Are you sure you want to delete zone ${index + 1}?`);
    if (!confirmed) return;
    setSaving(true);
    try {
      const updatedZones = zones.filter((_, i) => i !== index);
      const deviceRef = ref(rtdb, `${deviceId}`);
      await update(deviceRef, { zones: updatedZones });
      if (editingZoneIndex === index) {
        setEditingZoneIndex(null);
      } else if (editingZoneIndex > index) {
        setEditingZoneIndex(editingZoneIndex - 1); // Adjust index if a previous element is deleted
      }
    } catch (err) {
      alert("Failed to delete zone: " + err.message);
    }
    setSaving(false);
  };

  const handleCancelTemp = () => {
    setTempCenter(null);
  };

  const markerIcon = status === "OUTSIDE"
    ? "http://maps.google.com/mapfiles/ms/icons/red-dot.png"
    : status === "INSIDE"
      ? "http://maps.google.com/mapfiles/ms/icons/green-dot.png"
      : "http://maps.google.com/mapfiles/ms/icons/yellow-dot.png";

  const currentMapOptions = {
    ...mapOptions,
    draggableCursor: (zones.length < 3 && editingZoneIndex === null) ? "crosshair" : "grab",
  };

  const hasValidLocation = tempCenter || zones.length > 0 || (latitude != null && longitude != null);

  if (!hasValidLocation) {
    return (
      <div className="h-full w-full bg-slate-100 flex items-center justify-center relative shadow-inner">
        <div className="bg-white p-8 rounded-2xl shadow-lg max-w-md text-center border mx-4 border-slate-200">
          <div className="flex h-20 w-20 items-center justify-center rounded-full bg-blue-50 mx-auto mb-6">
            <span className="text-blue-500 text-4xl animate-pulse">📡</span>
          </div>
          <h2 className="text-2xl font-bold text-slate-800 mb-3">Waiting for Device</h2>
          <p className="text-slate-600 mb-6 text-sm leading-relaxed">
            The map interface will become available automatically once the first location ping is fetched from the wristband device.
          </p>
          <div className="flex items-center justify-center space-x-2 bg-blue-50 py-3 px-4 rounded-lg">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-blue-500"></span>
            </span>
            <span className="text-xs font-bold tracking-wider text-blue-700 uppercase">Listening for coordinates...</span>
          </div>
        </div>
      </div>
    );
  }

  const mapCenter = tempCenter || (zones.length > 0 ? zones[0].center : (latitude !== 0 && longitude !== 0 ? { lat: latitude, lng: longitude } : { lat: 37.7749, lng: -122.4194 }));

  return (
    <div className="h-full relative">
      <GoogleMap
        center={mapCenter}
        zoom={15}
        mapContainerStyle={mapContainerStyle}
        options={currentMapOptions}
        onLoad={onMapLoad}
        onClick={handleMapClick}
      >
        {latitude != null && longitude != null && latitude !== 0 && longitude !== 0 && (
          <MarkerF
            position={{ lat: latitude, lng: longitude }}
            icon={markerIcon}
            title="Child's Location"
          />
        )}

        {zones.map((zone, index) => (
          <CircleF
            key={`zone-${index}`}
            onLoad={(circle) => { circleRefs.current[index] = circle; }}
            center={zone.center}
            radius={zone.radius}
            editable={editingZoneIndex === index}
            draggable={editingZoneIndex === index}
            options={{
              fillColor: editingZoneIndex === index ? "#fbbf24" : "#3b82f6",
              fillOpacity: 0.15,
              strokeColor: editingZoneIndex === index ? "#f59e0b" : "#2563eb",
              strokeOpacity: 0.8,
              strokeWeight: 2,
            }}
          />
        ))}

        {tempCenter && (
          <CircleF
            center={tempCenter}
            radius={Number(tempRadius)}
            options={{
              fillColor: "#f59e0b",
              fillOpacity: 0.2,
              strokeColor: "#d97706",
              strokeOpacity: 0.8,
              strokeWeight: 2,
              strokeDashArray: "5 5",
            }}
          />
        )}

        {tempCenter && (
          <MarkerF
            position={tempCenter}
            icon="http://maps.google.com/mapfiles/ms/icons/orange-dot.png"
            title="New Zone Center"
          />
        )}
      </GoogleMap>

      <ZoneControls
        tempCenter={tempCenter}
        tempRadius={tempRadius}
        setTempRadius={setTempRadius}
        zones={zones}
        editingZoneIndex={editingZoneIndex}
        setEditingZoneIndex={setEditingZoneIndex}
        saving={saving}
        onSaveNewZone={handleSaveNewZone}
        onSaveEdits={handleSaveEdits}
        onDeleteZone={handleDeleteZone}
        onCancelTemp={handleCancelTemp}
      />

      {zones.length === 0 && !tempCenter && (
        <div className="absolute top-8 left-1/2 transform -translate-x-1/2 bg-white px-6 py-4 rounded-xl shadow-2xl border-2 border-blue-500 text-center animate-bounce z-50 pointer-events-none">
          <div className="text-blue-500 text-3xl mb-1">🎯 🗺️</div>
          <h2 className="text-xl font-bold text-gray-800">Add Safe Zone</h2>
          <p className="text-gray-600 font-medium">Click anywhere on the map to place the zone center.</p>
        </div>
      )}
      
    </div>
  );
}
