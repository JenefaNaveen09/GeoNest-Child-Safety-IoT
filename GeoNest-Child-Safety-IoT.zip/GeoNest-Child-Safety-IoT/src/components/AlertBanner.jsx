export default function AlertBanner({ alertType = "GEO", allAlerts = [] }) {
  const getAlertConfig = (type) => {
    switch (type) {
      case "FALL":
        return {
          bg: "bg-gradient-to-r from-rose-700 to-rose-600",
          icon: "🚑",
          title: "MEDICAL EMERGENCY",
          message: "A severe fall has been detected!",
          pulse: true
        };
      case "GEO":
        return {
          bg: "bg-gradient-to-r from-red-600 to-red-500",
          icon: "🚨",
          title: "SECURITY ALERT",
          message: "Child is outside the designated safe zone!",
          pulse: true
        };
      case "ZONE_BREACH":
        return {
          bg: "bg-gradient-to-r from-orange-600 to-orange-500",
          icon: "⚠️",
          title: "ZONE BREACH",
          message: "Child has left the safe zone area!",
          pulse: true
        };
      case "ZONE_RETURN":
        return {
          bg: "bg-gradient-to-r from-emerald-600 to-emerald-500",
          icon: "✅",
          title: "ZONE RETURN",
          message: "Child has returned to the safe zone.",
          pulse: false
        };
      case "HEALTH_EMERGENCY":
        return {
          bg: "bg-gradient-to-r from-purple-700 to-purple-600",
          icon: "🏥",
          title: "HEALTH EMERGENCY",
          message: "Critical health condition detected - SpO2 critically low!",
          pulse: true
        };
      case "HEALTH_DANGER":
        return {
          bg: "bg-gradient-to-r from-amber-600 to-amber-500",
          icon: "💓",
          title: "HEALTH ALERT",
          message: "Elevated heart rate detected while stationary!",
          pulse: true
        };
      case "HEAT_ALERT":
        return {
          bg: "bg-gradient-to-r from-red-500 to-orange-500",
          icon: "🔥",
          title: "HEAT ALERT",
          message: "High environmental temperature detected!",
          pulse: true
        };
      default:
        return {
          bg: "bg-gradient-to-r from-slate-600 to-slate-500",
          icon: "ℹ️",
          title: "NOTIFICATION",
          message: "",
          pulse: false
        };
    }
  };

  const config = getAlertConfig(alertType);

  return (
    <div className={`text-white shadow-md z-50 animate-in slide-in-from-top-4 fade-in duration-300 ${config.bg}`}>
      <div className="max-w-7xl mx-auto px-4 py-3 sm:px-6 lg:px-8 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <span className="flex h-8 w-8 items-center justify-center rounded-full bg-white/20 text-lg">
            {config.icon}
          </span>
          <div>
            <p className="font-bold text-xs sm:text-sm tracking-wide uppercase opacity-80">
              {config.title}
            </p>
            <p className="font-semibold text-sm sm:text-base tracking-wide">
              {config.message}
            </p>
          </div>
        </div>
        <div className="hidden sm:block">
          {config.pulse && (
            <span className="inline-flex items-center rounded-md bg-white/20 px-2.5 py-0.5 text-xs font-medium text-white shadow-sm ring-1 ring-inset ring-white/30 animate-pulse">
              Immediate Action Required
            </span>
          )}
        </div>
      </div>

      {/* Additional alerts indicator */}
      {allAlerts.length > 1 && (
        <div className="max-w-7xl mx-auto px-4 pb-2">
          <div className="flex flex-wrap gap-2">
            {allAlerts.map((alert, idx) => (
              <span
                key={idx}
                className={`px-2 py-1 rounded text-xs font-medium ${
                  alert === alertType
                    ? "bg-white text-slate-800"
                    : "bg-white/20 text-white"
                }`}
              >
                {getAlertConfig(alert).icon} {getAlertConfig(alert).title}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
