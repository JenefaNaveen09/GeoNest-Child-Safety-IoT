import { useEffect, useState } from "react";
import { ref, onValue } from "firebase/database";
import { rtdb } from "../firebase/config";

export default function useDeviceData(deviceId) {
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!deviceId) {
      setLoading(false);
      setError("No device ID provided");
      return;
    }

    const deviceRef = ref(rtdb, `${deviceId}`);

    const unsubscribe = onValue(
      deviceRef,
      (snapshot) => {
        setLoading(false);
        if (snapshot.exists()) {
          setData({ ...snapshot.val(), deviceId });
          setError(null);
        } else {
          // Device doesn't exist yet — this is fine, it just means hardware hasn't pinged.
          // We clear any old errors and keep data as null to show placeholders.
          setData(null);
          setError(null);
        }
      },
      (err) => {
        setLoading(false);
        setError(err.message);
        console.error("Realtime Database listener error:", err);
      }
    );

    return () => unsubscribe();
  }, [deviceId]);

  return { data, error, loading };
}
